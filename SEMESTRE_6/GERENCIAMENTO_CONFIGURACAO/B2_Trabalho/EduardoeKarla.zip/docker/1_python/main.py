
def soma_um_e_um():
    resultado = 1 + 1
    return resultado

if __name__ == "__main__":
    resultado = soma_um_e_um()
    print(f"O resultado da soma 1 + 1 é: {resultado}")
