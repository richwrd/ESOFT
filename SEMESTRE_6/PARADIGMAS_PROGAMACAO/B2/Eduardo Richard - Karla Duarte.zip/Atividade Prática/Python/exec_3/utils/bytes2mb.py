def bytes_to_mb(bytes):
    return bytes / (1024 * 1024)